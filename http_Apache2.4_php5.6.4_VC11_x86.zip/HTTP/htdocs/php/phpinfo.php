<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Apache</title>
</head>
<body>
<?php
	phpinfo();
?>
</body>
</html>