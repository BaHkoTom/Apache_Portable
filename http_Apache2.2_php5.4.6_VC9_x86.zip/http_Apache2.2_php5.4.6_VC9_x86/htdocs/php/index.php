<?php date_default_timezone_set("Europe/Sofia"); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Apache</title>
</head>
<body>
Testing PHP...<br /><br />
<?php
	echo "PHP...<br />is alive!!!<br />I think... but I may be wrong... but who am I to judge other living things?<br />";
?>
<br /><br /><br /><br />If you want to see the php info click the link bellow<br /><br />
<a href="phpinfo.php">phpinfo.php</a>
</body>
</html>